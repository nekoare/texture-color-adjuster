namespace TexColAdjuster.Runtime
{
    public enum ColorAdjustmentMode
    {
        LabHistogramMatching,
        HueShift,
        ColorTransfer,
        AdaptiveAdjustment
    }
}
